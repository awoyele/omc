<?php namespace Illuminate\Filesystem;

class FileNotFoundException extends \Exception {}
