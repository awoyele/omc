# Laravel Envoy

Elegant SSH tasks for PHP.

Official documentation [is located here](http://laravel.com/docs/5.1/envoy).
