<?php

namespace Illuminate\Contracts\Bus;

interface SelfHandling
{
}
